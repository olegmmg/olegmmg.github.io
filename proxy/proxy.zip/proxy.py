#!/usr/bin/env python3
"""
pip install cryptography requests
pythonw proxy.py --port 8080 --blocklist-url https://ваш-сайт.ru/blocklist.txt
"""

import socket
import threading
import argparse
import os
import sys
import re
import logging
import ssl
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

try:
    import requests
except ImportError:
    print("ERROR: requests library is required. Run: pip install requests")
    sys.exit(1)

try:
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
except ImportError:
    print("ERROR: cryptography library is required. Run: pip install cryptography")
    sys.exit(1)

# ── Paths ──────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent.resolve()
DEFAULT_BLOCKLIST = BASE_DIR / "blocklist.txt"          # локальный кэш
BLOCK_PAGE        = BASE_DIR / "blocked.html"

CA_CERT_PATH = BASE_DIR / "webfilter-ca-cert.pem"
CA_KEY_PATH  = BASE_DIR / "webfilter-ca-key.pem"

# ── Logging ────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
log = logging.getLogger("webfilter")

# ── Certificate Authority ──────────────────────────────────────────────────────
class CertificateAuthority:
    def __init__(self, cert_path: Path, key_path: Path):
        self.cert_path = cert_path
        self.key_path = key_path
        self._cert = None
        self._private_key = None
        self._load_or_generate()

    def _load_or_generate(self):
        if self.cert_path.exists() and self.key_path.exists():
            try:
                with open(self.cert_path, "rb") as f:
                    self._cert = x509.load_pem_x509_certificate(f.read())
                with open(self.key_path, "rb") as f:
                    self._private_key = serialization.load_pem_private_key(f.read(), password=None)
                log.info(f"Loaded CA from {self.cert_path}")
                return
            except Exception as e:
                log.warning(f"Failed to load existing CA: {e}. Generating new one.")

        log.info("Generating new Certificate Authority...")
        private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COUNTRY_NAME, "XX"),
            x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, "Proxy"),
            x509.NameAttribute(NameOID.LOCALITY_NAME, "Local"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "WebFilter"),
            x509.NameAttribute(NameOID.COMMON_NAME, "WebFilter CA"),
        ])
        cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            issuer
        ).public_key(
            private_key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.now(timezone.utc)
        ).not_valid_after(
            datetime.now(timezone.utc).replace(year=datetime.now(timezone.utc).year + 10)
        ).add_extension(
            x509.BasicConstraints(ca=True, path_length=None), critical=True
        ).sign(private_key, hashes.SHA256())

        with open(self.cert_path, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))
        with open(self.key_path, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            ))
        self._cert = cert
        self._private_key = private_key
        log.info(f"CA generated and saved to {self.cert_path}")
        log.info("IMPORTANT: Install this CA certificate in your system/browser trust store!")

    def generate_cert(self, hostname: str):
        host_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, hostname)])
        cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            self._cert.subject
        ).public_key(
            host_key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.now(timezone.utc)
        ).not_valid_after(
            datetime.now(timezone.utc).replace(year=datetime.now(timezone.utc).year + 1)
        ).add_extension(
            x509.SubjectAlternativeName([x509.DNSName(hostname)]),
            critical=False,
        ).sign(self._private_key, hashes.SHA256())

        cert_pem = cert.public_bytes(serialization.Encoding.PEM)
        key_pem = host_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption()
        )
        return cert_pem, key_pem

# ── Blocklist (с удалённой загрузкой) ──────────────────────────────────────────
class Blocklist:
    def __init__(self, local_path: Path, remote_url: str = None, update_interval: int = 3600):
        self.local_path = local_path
        self.remote_url = remote_url
        self.update_interval = update_interval
        self.entries: set[str] = set()
        self._last_update = 0
        self._lock = threading.Lock()
        self.reload()

    def _download_remote(self) -> str:
        """Загружает список с удалённого сервера. Возвращает текст или None при ошибке."""
        if not self.remote_url:
            return None
        try:
            resp = requests.get(self.remote_url, timeout=10)
            resp.raise_for_status()
            log.info(f"Downloaded blocklist from {self.remote_url}")
            return resp.text
        except Exception as e:
            log.warning(f"Failed to download blocklist: {e}")
            return None

    def reload(self):
        """Перезагружает список: сначала пробует удалённый, затем локальный."""
        with self._lock:
            now = time.time()
            # Проверяем, не пора ли обновить с удалённого сервера
            if self.remote_url and (now - self._last_update) >= self.update_interval:
                remote_text = self._download_remote()
                if remote_text is not None:
                    self._parse_entries(remote_text)
                    # Сохраняем в локальный файл для резерва
                    try:
                        self.local_path.write_text(remote_text, encoding="utf-8")
                        log.info(f"Saved remote blocklist to {self.local_path}")
                    except Exception as e:
                        log.warning(f"Failed to save local copy: {e}")
                    self._last_update = now
                    return

            # Если удалённого нет или не обновляли — читаем локальный файл
            try:
                if self.local_path.exists():
                    text = self.local_path.read_text(encoding="utf-8")
                    self._parse_entries(text)
                    log.info(f"Loaded local blocklist: {len(self.entries)} entries")
                else:
                    self.entries.clear()
                    log.warning("No blocklist available.")
            except Exception as e:
                log.error(f"Failed to load local blocklist: {e}")
                self.entries.clear()

    def _parse_entries(self, text: str):
        entries = set()
        for line in text.splitlines():
            line = line.strip().lower()
            if line and not line.startswith("#"):
                line = re.sub(r'^https?://', '', line).rstrip('/')
                entries.add(line)
        self.entries = entries

    def is_blocked(self, host: str) -> bool:
        # Периодически вызываем reload (при каждом запросе проверяем время)
        with self._lock:
            now = time.time()
            if self.remote_url and (now - self._last_update) >= self.update_interval:
                # Запускаем обновление в отдельном потоке, чтобы не блокировать запрос
                threading.Thread(target=self.reload, daemon=True).start()
        host = host.lower().split(":")[0]
        if host in self.entries:
            return True
        for entry in self.entries:
            if host.endswith("." + entry) or host == entry:
                return True
        return False

# ── Block page loader ──────────────────────────────────────────────────────────
def load_block_page(host: str, protocol: str = "https", path: str = "/") -> bytes:
    try:
        html = BLOCK_PAGE.read_text(encoding="utf-8")
        original_url = f"{protocol}://{host}{path}"
        html = html.replace("{{HOST}}", host)
        html = html.replace("{{PROTOCOL}}", protocol)
        html = html.replace("{{ORIGINAL_URL}}", original_url)
    except FileNotFoundError:
        html = f"<h1>Access Denied</h1><p>{host} is blocked.</p>"
    response = (
        "HTTP/1.1 403 Forbidden\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        f"Content-Length: {len(html.encode())}\r\n"
        "Connection: close\r\n"
        "\r\n"
        + html
    )
    return response.encode("utf-8")

def build_redirect(host: str, path: str) -> bytes:
    location = f"https://{host}{path}"
    response = (
        "HTTP/1.1 302 Found\r\n"
        f"Location: {location}\r\n"
        "Content-Length: 0\r\n"
        "Connection: close\r\n"
        "\r\n"
    )
    return response.encode()

# ── Proxy handler ──────────────────────────────────────────────────────────────
class ProxyHandler(threading.Thread):
    def __init__(self, conn: socket.socket, addr, blocklist: Blocklist,
                 ca: CertificateAuthority, enable_mitm: bool = True,
                 bypass_ttl: int = 5):
        super().__init__(daemon=True)
        self.conn = conn
        self.addr = addr
        self.blocklist = blocklist
        self.ca = ca
        self.enable_mitm = enable_mitm
        self.bypass_ttl = bypass_ttl

    def run(self):
        try:
            self._handle()
        except Exception as e:
            log.debug(f"Handler error: {e}")
        finally:
            self.conn.close()

    def _has_bypass_param(self, request_data: bytes) -> bool:
        try:
            text = request_data.decode('utf-8', errors='ignore')
            first_line = text.split('\r\n')[0]
            if '__bypass=1' in first_line:
                return True
        except:
            pass
        return False

    def _get_path_from_request(self, data: bytes) -> str:
        try:
            first_line = data.split(b'\r\n')[0].decode('utf-8', errors='ignore')
            parts = first_line.split()
            if len(parts) >= 2:
                url = parts[1]
                if url.startswith("http://") or url.startswith("https://"):
                    parsed = urlparse(url)
                    return parsed.path or "/"
                else:
                    return url
        except:
            pass
        return "/"

    def _handle(self):
        data = b""
        while b"\r\n\r\n" not in data:
            chunk = self.conn.recv(4096)
            if not chunk:
                return
            data += chunk

        first_line = data.split(b"\r\n")[0].decode("utf-8", errors="replace")
        parts = first_line.split()
        if len(parts) < 2:
            return

        method, url = parts[0], parts[1]

        # ── HTTPS CONNECT ──────────────────────────────────────────────────────
        if method == "CONNECT":
            host_port = url
            host = host_port.split(":")[0]
            port = int(host_port.split(":")[1]) if ":" in host_port else 443

            blocked = self.blocklist.is_blocked(host)

            if blocked and is_bypass_allowed(host):
                log.info(f"⏩ BYPASS TUNNEL {host}")
                try:
                    remote = socket.create_connection((host, port), timeout=10)
                    self.conn.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                    self._tunnel(self.conn, remote)
                except Exception as e:
                    log.debug(f"Tunnel error {host}: {e}")
                return

            if blocked and self.enable_mitm:
                self.conn.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                self._mitm_handle(host, port)
                return
            elif blocked and not self.enable_mitm:
                self.conn.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                return
            else:
                log.info(f"✅ ALLOWED {host}")
                try:
                    remote = socket.create_connection((host, port), timeout=10)
                    self.conn.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                    self._tunnel(self.conn, remote)
                except Exception as e:
                    log.debug(f"Tunnel error {host}: {e}")
                return

        # ── Plain HTTP ─────────────────────────────────────────────────────────
        if url.startswith("http://"):
            parsed = urlparse(url)
            host = parsed.hostname or ""
            port = parsed.port or 80
            protocol = "http"
            path = parsed.path or "/"
        else:
            host = url.split("/")[0]
            port = 80
            protocol = "http"
            path = url if url.startswith("/") else "/" + url

        blocked = self.blocklist.is_blocked(host)

        if blocked:
            if self._has_bypass_param(data) or is_bypass_allowed(host):
                log.info(f"⏩ BYPASS {host} (HTTP)")
                try:
                    remote = socket.create_connection((host, port), timeout=10)
                    remote.sendall(data)
                    self._relay(self.conn, remote)
                except Exception as e:
                    log.debug(f"HTTP bypass relay error: {e}")
                return
            else:
                log.info(f"🚫 BLOCKED {host}")
                self.conn.sendall(load_block_page(host, protocol, path))
                return

        log.info(f"✅ ALLOWED {host}")
        try:
            remote = socket.create_connection((host, port), timeout=10)
            remote.sendall(data)
            self._relay(self.conn, remote)
        except Exception as e:
            log.debug(f"HTTP relay error {host}: {e}")

    def _mitm_handle(self, host: str, port: int):
        cert_pem, key_pem = self.ca.generate_cert(host)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pem") as cert_file, \
             tempfile.NamedTemporaryFile(delete=False, suffix=".pem") as key_file:
            cert_file.write(cert_pem)
            key_file.write(key_pem)
            cert_path = cert_file.name
            key_path = key_file.name

        try:
            context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            context.load_cert_chain(certfile=cert_path, keyfile=key_path)
            tls_conn = context.wrap_socket(self.conn, server_side=True)
        except Exception as e:
            log.error(f"TLS handshake failed: {e}")
            return
        finally:
            os.unlink(cert_path)
            os.unlink(key_path)

        try:
            request_data = tls_conn.recv(4096)
            if not request_data:
                return

            if self._has_bypass_param(request_data):
                log.info(f"⏩ BYPASS REQUEST {host} — adding to cache and redirecting")
                add_bypass_host(host, self.bypass_ttl)
                path = self._get_path_from_request(request_data)
                redirect = build_redirect(host, path)
                tls_conn.sendall(redirect)
                return

            log.info(f"🚫 BLOCKED {host}")
            path = self._get_path_from_request(request_data)
            response = load_block_page(host, "https", path)
            tls_conn.sendall(response)
        except Exception as e:
            log.debug(f"MITM error: {e}")
        finally:
            tls_conn.close()

    def _relay(self, client: socket.socket, remote: socket.socket):
        remote.settimeout(10)
        try:
            while True:
                chunk = remote.recv(8192)
                if not chunk:
                    break
                client.sendall(chunk)
        except Exception:
            pass
        finally:
            remote.close()

    def _tunnel(self, client: socket.socket, remote: socket.socket):
        client.setblocking(False)
        remote.setblocking(False)
        import select
        sockets = [client, remote]
        while True:
            try:
                r, _, e = select.select(sockets, [], sockets, 10)
                if e:
                    break
                if not r:
                    break
                for s in r:
                    other = remote if s is client else client
                    try:
                        data = s.recv(8192)
                        if not data:
                            return
                        other.sendall(data)
                    except Exception:
                        return
            except Exception:
                break
        remote.close()

# ── Bypass cache ───────────────────────────────────────────────────────────────
bypass_cache = {}
bypass_lock = threading.Lock()

def is_bypass_allowed(host: str) -> bool:
    with bypass_lock:
        expires = bypass_cache.get(host)
        if expires and time.time() < expires:
            return True
        if expires:
            del bypass_cache[host]
        return False

def add_bypass_host(host: str, ttl: int):
    with bypass_lock:
        bypass_cache[host] = time.time() + ttl

# ── Server ─────────────────────────────────────────────────────────────────────
def run_server(port: int, blocklist_local: Path, blocklist_url: str,
               enable_mitm: bool, bypass_ttl: int):
    blocklist = Blocklist(blocklist_local, blocklist_url)
    ca = CertificateAuthority(CA_CERT_PATH, CA_KEY_PATH) if enable_mitm else None

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", port))
    server.listen(256)

    log.info(f"WebFilter proxy running on 127.0.0.1:{port}")
    log.info(f"Local blocklist : {blocklist_local}")
    if blocklist_url:
        log.info(f"Remote blocklist: {blocklist_url}")
    log.info(f"Block page      : {BLOCK_PAGE}")
    log.info(f"MITM mode       : {'ON' if enable_mitm else 'OFF'}")
    if enable_mitm:
        log.info(f"CA cert         : {CA_CERT_PATH}")

    while True:
        try:
            conn, addr = server.accept()
            ProxyHandler(conn, addr, blocklist, ca, enable_mitm, bypass_ttl).start()
        except KeyboardInterrupt:
            log.info("Shutting down.")
            break
        except Exception as e:
            log.error(f"Accept error: {e}")

# ── Entry point ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="WebFilter - local proxy with blocklist and MITM")
    parser.add_argument("--port", type=int, default=8080, help="Proxy port")
    parser.add_argument("--blocklist", type=Path, default=DEFAULT_BLOCKLIST,
                        help="Path to local blocklist file (cache)")
    parser.add_argument("--blocklist-url", type=str, default=None,
                        help="URL to remote blocklist (e.g., https://example.com/blocklist.txt)")
    parser.add_argument("--bypass-ttl", type=int, default=5,
                        help="Bypass cache TTL in seconds")
    parser.add_argument("--mitm", action="store_true", default=True)
    parser.add_argument("--no-mitm", dest="mitm", action="store_false")
    args = parser.parse_args()

    run_server(args.port, args.blocklist, args.blocklist_url, args.mitm, args.bypass_ttl)