#!/usr/bin/env python3
"""
setup_autostart.py — настройка автозапуска WebFilter (скрытый режим)
Поддерживает: Linux (systemd), Windows (реестр + pythonw), macOS (LaunchAgent)

Использование:
  python setup_autostart.py [--port 8080] [--blocklist-url https://...]
  python setup_autostart.py --remove
"""

import sys
import os
import platform
import argparse
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent.resolve()
PROXY_SCRIPT = SCRIPT_DIR / "proxy.py"

# Значения по умолчанию
DEFAULT_PORT = 8080
DEFAULT_BLOCKLIST_URL = "https://olegmmg.github.io/block.txt"

# На Windows используем pythonw.exe для скрытого запуска
if platform.system() == "Windows":
    PYTHON_EXE = Path(sys.executable).with_name("pythonw.exe")
else:
    PYTHON_EXE = sys.executable

def build_command(port: int, blocklist_url: str) -> str:
    """Возвращает строку команды для запуска прокси с аргументами."""
    return f'"{PYTHON_EXE}" "{PROXY_SCRIPT}" --port {port} --blocklist-url {blocklist_url}'

def linux_systemd(port: int, blocklist_url: str):
    service = f"""[Unit]
Description=WebFilter Proxy
After=network.target

[Service]
Type=simple
ExecStart={build_command(port, blocklist_url)}
WorkingDirectory={SCRIPT_DIR}
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
"""
    service_path = Path("/etc/systemd/system/webfilter.service")
    try:
        service_path.write_text(service)
        os.system("systemctl daemon-reload")
        os.system("systemctl enable webfilter")
        os.system("systemctl start webfilter")
        print("✅ Systemd service installed and started.")
        print("   Управление: systemctl start/stop/status webfilter")
    except PermissionError:
        user_dir = Path.home() / ".config/systemd/user"
        user_dir.mkdir(parents=True, exist_ok=True)
        (user_dir / "webfilter.service").write_text(service)
        os.system("systemctl --user daemon-reload")
        os.system("systemctl --user enable webfilter")
        os.system("systemctl --user start webfilter")
        print("✅ User-level systemd service installed (no root needed).")
        print("   Управление: systemctl --user start/stop/status webfilter")

def linux_autostart_xdg(port: int, blocklist_url: str):
    autostart_dir = Path.home() / ".config/autostart"
    autostart_dir.mkdir(parents=True, exist_ok=True)
    entry = f"""[Desktop Entry]
Type=Application
Name=WebFilter
Exec={build_command(port, blocklist_url)}
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
"""
    (autostart_dir / "webfilter.desktop").write_text(entry)
    print("✅ XDG autostart entry created (~/.config/autostart/webfilter.desktop)")

def windows_registry(port: int, blocklist_url: str):
    import winreg
    key_path = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
    value = build_command(port, blocklist_url)
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "WebFilter", 0, winreg.REG_SZ, value)
        winreg.CloseKey(key)
        print("✅ Автозапуск добавлен в реестр Windows (HKCU\\...\\Run).")
        print(f"   Команда: {value}")
        print("   Прокси будет запускаться скрыто (без окна).")
        print("   Для удаления запустите: setup_autostart.py --remove")
    except Exception as e:
        print(f"❌ Ошибка реестра: {e}")

def windows_registry_remove():
    import winreg
    key_path = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(key, "WebFilter")
        winreg.CloseKey(key)
        print("✅ Запись удалена из реестра.")
    except FileNotFoundError:
        print("ℹ️  Запись не найдена в реестре.")

def macos_launchagent(port: int, blocklist_url: str):
    plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>             <string>com.webfilter.proxy</string>
  <key>ProgramArguments</key>
  <array>
    <string>{PYTHON_EXE}</string>
    <string>{PROXY_SCRIPT}</string>
    <string>--port</string>
    <string>{port}</string>
    <string>--blocklist-url</string>
    <string>{blocklist_url}</string>
  </array>
  <key>RunAtLoad</key>         <true/>
  <key>KeepAlive</key>         <true/>
  <key>WorkingDirectory</key>  <string>{SCRIPT_DIR}</string>
</dict>
</plist>
"""
    agents = Path.home() / "Library/LaunchAgents"
    agents.mkdir(exist_ok=True)
    plist_path = agents / "com.webfilter.proxy.plist"
    plist_path.write_text(plist)
    os.system(f"launchctl load {plist_path}")
    print("✅ LaunchAgent создан и загружен.")
    print(f"   Файл: {plist_path}")

# ── Main ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Настройка автозапуска WebFilter")
    parser.add_argument("--remove", action="store_true", help="Удалить автозапуск")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"Порт прокси (по умолчанию {DEFAULT_PORT})")
    parser.add_argument("--blocklist-url", type=str, default=DEFAULT_BLOCKLIST_URL,
                        help=f"URL списка блокировки (по умолчанию {DEFAULT_BLOCKLIST_URL})")
    args = parser.parse_args()

    system = platform.system()

    print("WebFilter Autostart Setup")
    print(f"Platform : {system}")
    print(f"Script   : {PROXY_SCRIPT}")
    print(f"Python   : {PYTHON_EXE}")
    print(f"Port     : {args.port}")
    print(f"Blocklist: {args.blocklist_url}")
    print()

    if args.remove:
        if system == "Windows":
            windows_registry_remove()
        elif system == "Linux":
            # Удаление сервисов
            if Path("/etc/systemd/system/webfilter.service").exists():
                os.system("systemctl stop webfilter")
                os.system("systemctl disable webfilter")
                os.system("rm /etc/systemd/system/webfilter.service")
                print("✅ Systemd service removed.")
            user_service = Path.home() / ".config/systemd/user/webfilter.service"
            if user_service.exists():
                os.system("systemctl --user stop webfilter")
                os.system("systemctl --user disable webfilter")
                user_service.unlink()
                print("✅ User systemd service removed.")
            autostart_file = Path.home() / ".config/autostart/webfilter.desktop"
            if autostart_file.exists():
                autostart_file.unlink()
                print("✅ XDG autostart entry removed.")
        elif system == "Darwin":
            plist_path = Path.home() / "Library/LaunchAgents/com.webfilter.proxy.plist"
            if plist_path.exists():
                os.system(f"launchctl unload {plist_path}")
                plist_path.unlink()
                print("✅ LaunchAgent removed.")
        else:
            print(f"❌ Платформа не поддерживается: {system}")
            sys.exit(1)
        sys.exit(0)

    # Установка
    if system == "Linux":
        if Path("/run/systemd/system").exists():
            linux_systemd(args.port, args.blocklist_url)
        else:
            linux_autostart_xdg(args.port, args.blocklist_url)
    elif system == "Windows":
        windows_registry(args.port, args.blocklist_url)
    elif system == "Darwin":
        macos_launchagent(args.port, args.blocklist_url)
    else:
        print(f"❌ Платформа не поддерживается: {system}")
        sys.exit(1)

    print()
    print("─" * 55)
    print("ВАЖНО: Настройте прокси в браузере:")
    print(f"  Адрес: 127.0.0.1   Порт: {args.port}")
    print("  (HTTP и HTTPS)")
    print("─" * 55)