#!/usr/bin/env python3
"""
setup_autostart.py — настройка автозапуска WebFilter (скрытый режим)
Windows: создаёт ярлык в папке автозагрузки (Startup)
Linux: systemd или XDG autostart
macOS: LaunchAgent

Использование:
  python setup_autostart.py [--port 8080] [--blocklist-url https://...]
  python setup_autostart.py --remove
"""

import sys
import os
import platform
import argparse
from pathlib import Path

# Автоматическое определение папки proxy
def find_proxy_dir() -> Path:
    home = Path.home()
    possible_paths = [
        home / "proxy",
        home / "Downloads" / "proxy",
        home / "Desktop" / "proxy",
        Path(__file__).parent.resolve(),
    ]
    for path in possible_paths:
        if (path / "proxy.py").exists():
            return path
    return Path(__file__).parent.resolve()

SCRIPT_DIR = find_proxy_dir()
PROXY_SCRIPT = SCRIPT_DIR / "proxy.py"

DEFAULT_PORT = 8080
DEFAULT_BLOCKLIST_URL = "https://olegmmg.github.io/block.txt"

if platform.system() == "Windows":
    PYTHON_EXE = Path(sys.executable).with_name("pythonw.exe")
else:
    PYTHON_EXE = sys.executable

def build_command(port: int, blocklist_url: str) -> str:
    """Возвращает строку команды для запуска прокси."""
    return f'"{PYTHON_EXE}" "{PROXY_SCRIPT}" --port {port} --blocklist-url {blocklist_url}'

# ---------- Windows: ярлык в Startup ----------
def windows_create_shortcut(port: int, blocklist_url: str):
    import subprocess
    startup_folder = Path(os.environ["APPDATA"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    shortcut_path = startup_folder / "WebFilter.lnk"
    target = str(PYTHON_EXE)
    arguments = f'"{PROXY_SCRIPT}" --port {port} --blocklist-url {blocklist_url}'
    working_dir = str(SCRIPT_DIR)

    ps_command = f"""
    $WScriptShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WScriptShell.CreateShortcut("{shortcut_path}")
    $Shortcut.TargetPath = "{target}"
    $Shortcut.Arguments = '{arguments}'
    $Shortcut.WorkingDirectory = "{working_dir}"
    $Shortcut.WindowStyle = 7
    $Shortcut.Save()
    """
    try:
        subprocess.run(["powershell", "-Command", ps_command], check=True, capture_output=True)
        print("✅ Ярлык автозагрузки создан в:")
        print(f"   {shortcut_path}")
        print("   Прокси будет запускаться скрыто при входе в систему.")
    except Exception as e:
        print(f"❌ Ошибка создания ярлыка: {e}")

def windows_remove_shortcut():
    startup_folder = Path(os.environ["APPDATA"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    shortcut_path = startup_folder / "WebFilter.lnk"
    if shortcut_path.exists():
        shortcut_path.unlink()
        print("✅ Ярлык автозагрузки удалён.")
    else:
        print("ℹ️  Ярлык автозагрузки не найден.")

# ---------- Linux ----------
def linux_systemd(port: int, blocklist_url: str):
    service = f"""[Unit]
Description=WebFilter Proxy
After=network.target

[Service]
Type=simple
ExecStart={PYTHON_EXE} {PROXY_SCRIPT} --port {port} --blocklist-url {blocklist_url}
WorkingDirectory={SCRIPT_DIR}
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
"""
    service_path = Path("/etc/systemd/system/webfilter.service")
    try:
        service_path.write_text(service)
        os.system("systemctl daemon-reload")
        os.system("systemctl enable webfilter")
        os.system("systemctl start webfilter")
        print("✅ Systemd service installed.")
    except PermissionError:
        user_dir = Path.home() / ".config/systemd/user"
        user_dir.mkdir(parents=True, exist_ok=True)
        (user_dir / "webfilter.service").write_text(service)
        os.system("systemctl --user daemon-reload")
        os.system("systemctl --user enable webfilter")
        os.system("systemctl --user start webfilter")
        print("✅ User systemd service installed.")

def linux_autostart_xdg(port: int, blocklist_url: str):
    autostart_dir = Path.home() / ".config/autostart"
    autostart_dir.mkdir(parents=True, exist_ok=True)
    entry = f"""[Desktop Entry]
Type=Application
Name=WebFilter
Exec={PYTHON_EXE} {PROXY_SCRIPT} --port {port} --blocklist-url {blocklist_url}
Path={SCRIPT_DIR}
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
"""
    (autostart_dir / "webfilter.desktop").write_text(entry)
    print("✅ XDG autostart entry created.")

# ---------- macOS ----------
def macos_launchagent(port: int, blocklist_url: str):
    plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>             <string>com.webfilter.proxy</string>
  <key>ProgramArguments</key>
  <array>
    <string>{PYTHON_EXE}</string>
    <string>{PROXY_SCRIPT}</string>
    <string>--port</string>
    <string>{port}</string>
    <string>--blocklist-url</string>
    <string>{blocklist_url}</string>
  </array>
  <key>RunAtLoad</key>         <true/>
  <key>KeepAlive</key>         <true/>
  <key>WorkingDirectory</key>  <string>{SCRIPT_DIR}</string>
</dict>
</plist>
"""
    agents = Path.home() / "Library/LaunchAgents"
    agents.mkdir(exist_ok=True)
    plist_path = agents / "com.webfilter.proxy.plist"
    plist_path.write_text(plist)
    os.system(f"launchctl load {plist_path}")
    print("✅ LaunchAgent created.")

# ---------- Main ----------
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--remove", action="store_true")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--blocklist-url", type=str, default=DEFAULT_BLOCKLIST_URL)
    args = parser.parse_args()

    system = platform.system()

    print("WebFilter Autostart Setup")
    print(f"Platform    : {system}")
    print(f"Proxy folder: {SCRIPT_DIR}")
    print(f"Proxy script: {PROXY_SCRIPT}")
    print(f"Python      : {PYTHON_EXE}")
    print(f"Port        : {args.port}")
    print(f"Blocklist   : {args.blocklist_url}")
    print()

    if not PROXY_SCRIPT.exists() and not args.remove:
        print(f"❌ Файл {PROXY_SCRIPT} не найден!")
        print(f"   Поместите папку proxy в {Path.home() / 'proxy'}")
        sys.exit(1)

    if args.remove:
        if system == "Windows":
            windows_remove_shortcut()
        elif system == "Linux":
            # удаление systemd / autostart
            pass  # можно дописать при необходимости
        elif system == "Darwin":
            plist = Path.home() / "Library/LaunchAgents/com.webfilter.proxy.plist"
            if plist.exists():
                os.system(f"launchctl unload {plist}")
                plist.unlink()
                print("✅ LaunchAgent removed.")
        sys.exit(0)

    if system == "Windows":
        windows_create_shortcut(args.port, args.blocklist_url)
    elif system == "Linux":
        if Path("/run/systemd/system").exists():
            linux_systemd(args.port, args.blocklist_url)
        else:
            linux_autostart_xdg(args.port, args.blocklist_url)
    elif system == "Darwin":
        macos_launchagent(args.port, args.blocklist_url)
    else:
        print(f"❌ Платформа не поддерживается: {system}")
        sys.exit(1)

    print("\n" + "─" * 55)
    print("Настройте прокси в браузере: 127.0.0.1:" + str(args.port))
    print("─" * 55)